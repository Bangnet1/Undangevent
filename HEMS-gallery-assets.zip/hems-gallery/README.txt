HEMS - Gallery assets
Upload/extract the folder public/gallery into the root of repository Bangnet1/Undangevent.
Required image paths:
/gallery/Building_1.webp
/gallery/eswl.webp
/gallery/ugd.webp
/gallery/icu_isolation.webp
/gallery/suite_room.webp
/gallery/vvip_room.webp
/gallery/poly_exe.webp
/gallery/dental_2.webp
/gallery/mri.webp
/gallery/ct_scan_2.webp
